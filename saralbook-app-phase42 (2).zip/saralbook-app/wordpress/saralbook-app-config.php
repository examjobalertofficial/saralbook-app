<?php
/**
 * Plugin Name: SaralBook App Config
 * Description: Controls the SaralBook mobile app (Home sections, announcements, maintenance, service on/off) from the WordPress dashboard. No app update needed.
 * Version: 1.5.0
 * Author: SaralBook
 * License: GPLv2 or later
 *
 * Install on https://saralbook.com (the address is set in the app in lib/config/endpoints.dart).
 * Public address of the settings: https://saralbook.com/wp-json/saralbook/v1/config
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const SARALBOOK_APP_OPTION = 'saralbook_app_config';

/** Websites the app knows. Keys must match the ids inside the app. */
function saralbook_app_services() {
	return array(
		'examjobalert'  => 'Exam Job Alert',
		'saralbook'     => 'SaralBook',
		'saralbooktest' => 'SaralBook Test (mock tests)',
		'saralbookstore' => 'SaralBook Store',
		'onlinecalcy'   => 'Online Calcy',
	);
}

/** Features you can switch off. Keys must match the names inside the app. */
function saralbook_app_flags() {
	return array(
		'groups'          => 'Group Expenses',
		'group_chat'      => 'Group chat',
		'expense_tracker' => 'Expense Tracker',
	);
}

/** Domains the app accepts (it ignores any other address for safety). */
function saralbook_app_allowed_url( $url ) {
	$url = esc_url_raw( trim( (string) $url ), array( 'https' ) );
	if ( '' === $url ) {
		return '';
	}
	$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
	// SaralBook's own Google Play page is also allowed.
	if ( 'play.google.com' === $host && 0 === strpos( $url, 'https://play.google.com/store/apps/details?id=com.saralbook.app' ) ) {
		return $url;
	}
	foreach ( array( 'saralbook.com', 'examjobalert.com', 'onlinecalcy.com' ) as $domain ) {
		if ( $host === $domain || substr( $host, -strlen( $domain ) - 1 ) === '.' . $domain ) {
			return $url;
		}
	}
	return '';
}

/** The shortcut buttons under the app's Home header: id => label. Order = order in the app. */
function saralbook_app_shortcuts() {
	return array(
		'latest'        => 'Latest Jobs',
		'admit_card'    => 'Admit Card',
		'answer_key'    => 'Answer Key',
		'result'        => 'Result',
		'admission'     => 'Admission',
		'syllabus'      => 'Syllabus',
		'group_expense' => 'Group Expense',
		'resume_maker'  => 'Resume Maker',
		'doc_scanner'   => 'Document Scanner',
		'photo_resize'  => 'Photo Resize (for forms)',
		'pdf_compress'  => 'Compress PDF',
		'images_to_pdf' => 'Image to PDF',
	);
}

/** Social pages shown in the app's More tab: id => label, allowed websites, example. */
function saralbook_app_socials() {
	return array(
		'whatsapp'  => array( 'WhatsApp channel / group', array( 'whatsapp.com', 'wa.me' ), 'https://whatsapp.com/channel/...' ),
		'telegram'  => array( 'Telegram channel', array( 't.me', 'telegram.me', 'telegram.org' ), 'https://t.me/yourchannel' ),
		'facebook'  => array( 'Facebook page', array( 'facebook.com', 'fb.com', 'fb.me' ), 'https://www.facebook.com/yourpage' ),
		'instagram' => array( 'Instagram', array( 'instagram.com' ), 'https://www.instagram.com/yourname' ),
		'x'         => array( 'X (Twitter)', array( 'x.com', 'twitter.com' ), 'https://x.com/yourname' ),
		'linkedin'  => array( 'LinkedIn', array( 'linkedin.com' ), 'https://www.linkedin.com/company/yourname' ),
		'threads'   => array( 'Threads', array( 'threads.net', 'threads.com' ), 'https://www.threads.net/@yourname' ),
	);
}

/** A https link that belongs to the named social website, else ''. */
function saralbook_app_social_url( $id, $url ) {
	$all = saralbook_app_socials();
	if ( ! isset( $all[ $id ] ) ) {
		return '';
	}
	$url = esc_url_raw( trim( (string) $url ), array( 'https' ) );
	if ( '' === $url ) {
		return '';
	}
	$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
	foreach ( $all[ $id ][1] as $domain ) {
		if ( $host === $domain || substr( $host, -strlen( $domain ) - 1 ) === '.' . $domain ) {
			return $url;
		}
	}
	return '';
}

/* ---------- Settings page ---------- */

add_action( 'admin_menu', function () {
	add_menu_page( 'SaralBook App', 'SaralBook App', 'manage_options', 'saralbook-app', 'saralbook_app_render_page', 'dashicons-smartphone', 80 );
} );

add_action( 'admin_init', function () {
	register_setting( 'saralbook_app', SARALBOOK_APP_OPTION, array( 'sanitize_callback' => 'saralbook_app_sanitize' ) );
} );

function saralbook_app_sanitize( $in ) {
	$in  = is_array( $in ) ? $in : array();
	$out = array();

	$out['maintenance'] = array(
		'enabled'  => ! empty( $in['maintenance']['enabled'] ) ? 1 : 0,
		'blocking' => ! empty( $in['maintenance']['blocking'] ) ? 1 : 0,
		'message'  => sanitize_text_field( $in['maintenance']['message'] ?? '' ),
	);

	$out['announcements'] = array();
	for ( $i = 0; $i < 10; $i++ ) {
		$row = $in['announcements'][ $i ] ?? array();
		$out['announcements'][ $i ] = array(
			'title'   => sanitize_text_field( $row['title'] ?? '' ),
			'message' => sanitize_text_field( $row['message'] ?? '' ),
			'url'     => saralbook_app_allowed_url( $row['url'] ?? '' ),
		);
	}

	$out['social'] = array();
	foreach ( array_keys( saralbook_app_socials() ) as $id ) {
		$out['social'][ $id ] = saralbook_app_social_url( $id, $in['social'][ $id ] ?? '' );
	}

	// Ticked = shown. Unticked buttons are saved as hidden.
	$shown = isset( $in['shortcuts_show'] ) && is_array( $in['shortcuts_show'] ) ? $in['shortcuts_show'] : array();
	$out['shortcuts_hidden'] = array();
	foreach ( array_keys( saralbook_app_shortcuts() ) as $id ) {
		if ( empty( $shown[ $id ] ) ) {
			$out['shortcuts_hidden'][] = $id;
		}
	}

	$out['services'] = array();
	foreach ( array_keys( saralbook_app_services() ) as $id ) {
		$row = $in['services'][ $id ] ?? array();
		$out['services'][ $id ] = array(
			'enabled' => ! empty( $row['enabled'] ) ? 1 : 0,
			'message' => sanitize_text_field( $row['message'] ?? '' ),
		);
	}

	$out['flags'] = array();
	foreach ( array_keys( saralbook_app_flags() ) as $id ) {
		$out['flags'][ $id ] = ! empty( $in['flags'][ $id ] ) ? 1 : 0;
	}

	// Tool ids, separated by commas or spaces: letters, numbers and _ only.
	$ids = preg_split( '/[\s,]+/', strtolower( (string) ( $in['disabledTools'] ?? '' ) ) );
	$ids = array_filter( $ids, function ( $x ) {
		return (bool) preg_match( '/^[a-z0-9_]{1,40}$/', $x );
	} );
	$out['disabledTools'] = implode( ', ', array_slice( array_unique( $ids ), 0, 80 ) );

	$u = $in['update'] ?? array();
	$out['update'] = array(
		'minBuild'    => max( 0, (int) ( $u['minBuild'] ?? 0 ) ),
		'latestBuild' => max( 0, (int) ( $u['latestBuild'] ?? 0 ) ),
		'message'     => sanitize_text_field( $u['message'] ?? '' ),
		'url'         => saralbook_app_allowed_url( $u['url'] ?? '' ),
	);

	// OneSignal App ID (public, looks like 8-4-4-4-12 hex digits). Wrong format -> empty.
	$app_id          = strtolower( trim( (string) ( $in['push']['appId'] ?? '' ) ) );
	$out['push']     = array(
		'appId' => preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/', $app_id ) ? $app_id : '',
	);

	$out['sections'] = array();
	for ( $i = 0; $i < 8; $i++ ) {
		$row  = $in['sections'][ $i ] ?? array();
		$type = in_array( $row['type'] ?? '', array( 'feed', 'platforms', 'recent', 'favorites', 'expense' ), true ) ? $row['type'] : 'feed';
		$out['sections'][ $i ] = array(
			'type'    => $type,
			'title'   => sanitize_text_field( $row['title'] ?? '' ),
			'titleHi' => sanitize_text_field( $row['titleHi'] ?? '' ),
			'feedUrl' => saralbook_app_allowed_url( $row['feedUrl'] ?? '' ),
			'enabled' => ! empty( $row['enabled'] ) ? 1 : 0,
		);
	}

	$out['version'] = time();
	return $out;
}

function saralbook_app_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$o        = get_option( SARALBOOK_APP_OPTION, array() );
	$name     = SARALBOOK_APP_OPTION;
	$m        = $o['maintenance'] ?? array();
	$services = saralbook_app_services();
	?>
	<div class="wrap">
		<h1>SaralBook App</h1>
		<p>Changes appear in the app within a few minutes. Leave "Home sections" completely empty to use the app's built-in Home.</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'saralbook_app' ); ?>

			<h2>Maintenance</h2>
			<p>
				<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[maintenance][enabled]" value="1" <?php checked( ! empty( $m['enabled'] ) ); ?>> Show maintenance notice on Home</label><br>
				<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[maintenance][blocking]" value="1" <?php checked( ! empty( $m['blocking'] ) ); ?>> Block the whole app with a full-screen message (use only for real emergencies)</label>
			</p>
			<p><input type="text" class="large-text" placeholder="Message (optional)" name="<?php echo esc_attr( $name ); ?>[maintenance][message]" value="<?php echo esc_attr( $m['message'] ?? '' ); ?>"></p>

			<h2>Announcements (max 10)</h2>
			<table class="widefat striped"><thead><tr><th>Title</th><th>Message</th><th>Link (optional, https only, your sites)</th></tr></thead><tbody>
			<?php for ( $i = 0; $i < 10; $i++ ) : $r = $o['announcements'][ $i ] ?? array(); ?>
				<tr>
					<td><input type="text" class="regular-text" name="<?php echo esc_attr( $name ); ?>[announcements][<?php echo (int) $i; ?>][title]" value="<?php echo esc_attr( $r['title'] ?? '' ); ?>"></td>
					<td><input type="text" class="large-text" name="<?php echo esc_attr( $name ); ?>[announcements][<?php echo (int) $i; ?>][message]" value="<?php echo esc_attr( $r['message'] ?? '' ); ?>"></td>
					<td><input type="url" class="regular-text" name="<?php echo esc_attr( $name ); ?>[announcements][<?php echo (int) $i; ?>][url]" value="<?php echo esc_attr( $r['url'] ?? '' ); ?>"></td>
				</tr>
			<?php endfor; ?>
			</tbody></table>

			<h2>Home shortcut buttons</h2>
			<p>Tick the buttons you want under the app's Home header. Unticked buttons disappear and the rest move up (four in a row).</p>
			<?php $hid = (array) ( $o['shortcuts_hidden'] ?? array() ); ?>
			<table class="form-table"><tbody><tr><td>
			<?php foreach ( saralbook_app_shortcuts() as $id => $label ) : ?>
				<label style="display:inline-block;min-width:230px;margin:4px 0"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[shortcuts_show][<?php echo esc_attr( $id ); ?>]" value="1" <?php checked( ! in_array( $id, $hid, true ) ); ?>> <?php echo esc_html( $label ); ?></label>
			<?php endforeach; ?>
			</td></tr></tbody></table>

			<h2>Social media links (shown in the app's More tab)</h2>
			<p>Paste the full https link of each page. Leave empty to hide it. Only the matching website is accepted (for example a Telegram box accepts only t.me links).</p>
			<?php $so = $o['social'] ?? array(); ?>
			<table class="form-table"><tbody>
			<?php foreach ( saralbook_app_socials() as $id => $info ) : ?>
				<tr><th><?php echo esc_html( $info[0] ); ?></th><td><input type="url" class="large-text" placeholder="<?php echo esc_attr( $info[2] ); ?>" name="<?php echo esc_attr( $name ); ?>[social][<?php echo esc_attr( $id ); ?>]" value="<?php echo esc_attr( $so[ $id ] ?? '' ); ?>"></td></tr>
			<?php endforeach; ?>
			</tbody></table>

			<h2>Websites (turn one off if it is down)</h2>
			<table class="widefat striped"><thead><tr><th>Website</th><th>Available</th><th>Message when unavailable (optional)</th></tr></thead><tbody>
			<?php foreach ( $services as $id => $label ) :
				$r       = $o['services'][ $id ] ?? array();
				$enabled = isset( $r['enabled'] ) ? ! empty( $r['enabled'] ) : true; ?>
				<tr>
					<td><?php echo esc_html( $label ); ?></td>
					<td><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[services][<?php echo esc_attr( $id ); ?>][enabled]" value="1" <?php checked( $enabled ); ?>></td>
					<td><input type="text" class="large-text" name="<?php echo esc_attr( $name ); ?>[services][<?php echo esc_attr( $id ); ?>][message]" value="<?php echo esc_attr( $r['message'] ?? '' ); ?>"></td>
				</tr>
			<?php endforeach; ?>
			</tbody></table>

			<h2>Features (turn one off if it has a problem)</h2>
			<table class="widefat striped"><tbody>
			<?php foreach ( saralbook_app_flags() as $id => $label ) :
				$on = isset( $o['flags'][ $id ] ) ? ! empty( $o['flags'][ $id ] ) : true; ?>
				<tr>
					<td><?php echo esc_html( $label ); ?></td>
					<td><label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[flags][<?php echo esc_attr( $id ); ?>]" value="1" <?php checked( $on ); ?>> Available</label></td>
				</tr>
			<?php endforeach; ?>
			</tbody></table>

			<h2>Tools to turn off</h2>
			<p>Tool ids separated by commas, for example <code>resume_maker, pdf_merge</code>. Leave empty to keep every tool on.
			The ids are listed in the app's Admin panel (More &gt; Admin panel &gt; Tools).</p>
			<p><input type="text" class="large-text" name="<?php echo esc_attr( $name ); ?>[disabledTools]" value="<?php echo esc_attr( $o['disabledTools'] ?? '' ); ?>"></p>

			<h2>App updates</h2>
			<p>The build number is the number after the + in the app version (1.11.0+13 means build 13).
			Leave both at 0 for no update rules.</p>
			<?php $up = $o['update'] ?? array(); ?>
			<table class="form-table"><tbody>
				<tr><th>Must update below build</th><td><input type="number" min="0" name="<?php echo esc_attr( $name ); ?>[update][minBuild]" value="<?php echo (int) ( $up['minBuild'] ?? 0 ); ?>"> Older apps see a full-screen "Please update".</td></tr>
				<tr><th>Latest build</th><td><input type="number" min="0" name="<?php echo esc_attr( $name ); ?>[update][latestBuild]" value="<?php echo (int) ( $up['latestBuild'] ?? 0 ); ?>"> Older apps see a small "Update available" note on Home.</td></tr>
				<tr><th>Message (optional)</th><td><input type="text" class="large-text" name="<?php echo esc_attr( $name ); ?>[update][message]" value="<?php echo esc_attr( $up['message'] ?? '' ); ?>"></td></tr>
				<tr><th>Where to update (optional)</th><td><input type="url" class="large-text" placeholder="https://saralbook.com/app-download/" name="<?php echo esc_attr( $name ); ?>[update][url]" value="<?php echo esc_attr( $up['url'] ?? '' ); ?>"> Empty = the Google Play page.</td></tr>
			</tbody></table>

			<h2>Push notifications</h2>
			<p>Paste your OneSignal <strong>App ID</strong> (OneSignal dashboard &gt; Settings &gt; Keys &amp; IDs). It is not secret.
			Leave empty to keep notifications off in the app. The plugin that sends them is "SaralBook App Push".</p>
			<?php $pu = $o['push'] ?? array(); ?>
			<p><input type="text" class="regular-text" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" name="<?php echo esc_attr( $name ); ?>[push][appId]" value="<?php echo esc_attr( $pu['appId'] ?? '' ); ?>"></p>

			<h2>Home sections (top to bottom, max 8)</h2>
			<p><strong>Type "Latest posts"</strong> needs a Feed URL, for example<br>
			<code>https://examjobalert.com/wp-json/wp/v2/posts?categories=12&amp;per_page=15</code><br>
			To find a category number open <code>https://examjobalert.com/wp-json/wp/v2/categories?search=admit</code> in your browser and look for <code>"id"</code>.</p>
			<table class="widefat striped"><thead><tr><th>On</th><th>Type</th><th>Title (English)</th><th>Title (Hindi)</th><th>Feed URL</th></tr></thead><tbody>
			<?php for ( $i = 0; $i < 8; $i++ ) :
				$r    = $o['sections'][ $i ] ?? array();
				$type = $r['type'] ?? 'feed';
				$on   = ! empty( $r['enabled'] );
				$base = esc_attr( $name ) . '[sections][' . (int) $i . ']'; ?>
				<tr>
					<td><input type="checkbox" name="<?php echo $base; // phpcs:ignore WordPress.Security.EscapeOutput ?>[enabled]" value="1" <?php checked( $on ); ?>></td>
					<td>
						<select name="<?php echo $base; // phpcs:ignore WordPress.Security.EscapeOutput ?>[type]">
							<option value="feed" <?php selected( $type, 'feed' ); ?>>Latest posts</option>
							<option value="platforms" <?php selected( $type, 'platforms' ); ?>>Our platforms</option>
							<option value="recent" <?php selected( $type, 'recent' ); ?>>Recently viewed</option>
							<option value="favorites" <?php selected( $type, 'favorites' ); ?>>Favorites</option>
							<option value="expense" <?php selected( $type, 'expense' ); ?>>Expense summary</option>
						</select>
					</td>
					<td><input type="text" name="<?php echo $base; // phpcs:ignore WordPress.Security.EscapeOutput ?>[title]" value="<?php echo esc_attr( $r['title'] ?? '' ); ?>"></td>
					<td><input type="text" name="<?php echo $base; // phpcs:ignore WordPress.Security.EscapeOutput ?>[titleHi]" value="<?php echo esc_attr( $r['titleHi'] ?? '' ); ?>"></td>
					<td><input type="url" class="large-text" name="<?php echo $base; // phpcs:ignore WordPress.Security.EscapeOutput ?>[feedUrl]" value="<?php echo esc_attr( $r['feedUrl'] ?? '' ); ?>"></td>
				</tr>
			<?php endfor; ?>
			</tbody></table>

			<?php submit_button(); ?>
		</form>
		<p>App reads: <a href="<?php echo esc_url( rest_url( 'saralbook/v1/config' ) ); ?>" target="_blank"><?php echo esc_html( rest_url( 'saralbook/v1/config' ) ); ?></a></p>
	</div>
	<?php
}

/* ---------- Public JSON used by the app ---------- */

add_action( 'rest_api_init', function () {
	register_rest_route( 'saralbook/v1', '/config', array(
		'methods'             => 'GET',
		'callback'            => 'saralbook_app_rest_config',
		'permission_callback' => '__return_true',
	) );
} );

function saralbook_app_rest_config() {
	$o = get_option( SARALBOOK_APP_OPTION, array() );
	$m = $o['maintenance'] ?? array();

	$out = array(
		'version'       => (int) ( $o['version'] ?? 1 ),
		'maintenance'   => array(
			'enabled'  => ! empty( $m['enabled'] ),
			'blocking' => ! empty( $m['blocking'] ),
			'message'  => (string) ( $m['message'] ?? '' ),
		),
		'announcements' => array(),
		'services'      => array(),
	);

	foreach ( $o['announcements'] ?? array() as $i => $a ) {
		if ( '' === ( $a['title'] ?? '' ) && '' === ( $a['message'] ?? '' ) ) {
			continue;
		}
		$out['announcements'][] = array(
			'id'      => 'a' . $i,
			'title'   => (string) $a['title'],
			'message' => (string) $a['message'],
			'url'     => (string) ( $a['url'] ?? '' ),
		);
	}

	foreach ( array_keys( saralbook_app_services() ) as $id ) {
		$r                     = $o['services'][ $id ] ?? array();
		$out['services'][ $id ] = array(
			'enabled' => isset( $r['enabled'] ) ? ! empty( $r['enabled'] ) : true,
			'message' => (string) ( $r['message'] ?? '' ),
		);
	}

	$out['flags'] = array();
	foreach ( array_keys( saralbook_app_flags() ) as $id ) {
		$out['flags'][ $id ] = isset( $o['flags'][ $id ] ) ? ! empty( $o['flags'][ $id ] ) : true;
	}
	$out['disabledTools'] = array_values( array_filter( preg_split( '/[\s,]+/', (string) ( $o['disabledTools'] ?? '' ) ) ) );
	$u                    = $o['update'] ?? array();
	$out['update']        = array(
		'minBuild'    => (int) ( $u['minBuild'] ?? 0 ),
		'latestBuild' => (int) ( $u['latestBuild'] ?? 0 ),
		'message'     => (string) ( $u['message'] ?? '' ),
		'url'         => (string) ( $u['url'] ?? '' ),
	);

	$out['push'] = array( 'appId' => (string) ( $o['push']['appId'] ?? '' ) );

	$hidden_shortcuts = array();
	foreach ( (array) ( $o['shortcuts_hidden'] ?? array() ) as $hid ) {
		if ( is_string( $hid ) && isset( saralbook_app_shortcuts()[ $hid ] ) ) {
			$hidden_shortcuts[] = $hid;
		}
	}
	$out['shortcuts'] = array( 'hidden' => $hidden_shortcuts );

	$out['social'] = new stdClass();
	foreach ( array_keys( saralbook_app_socials() ) as $id ) {
		$link = saralbook_app_social_url( $id, $o['social'][ $id ] ?? '' );
		if ( '' !== $link ) {
			$out['social']->$id = $link;
		}
	}

	// Sections are only sent when you filled some in; otherwise the app uses its built-in Home.
	$sections = array();
	$used     = array();
	foreach ( $o['sections'] ?? array() as $i => $s ) {
		if ( empty( $s['enabled'] ) ) {
			continue;
		}
		if ( 'feed' === $s['type'] && '' === $s['feedUrl'] ) {
			continue;
		}
		$id = preg_replace( '/[^a-z0-9_-]/', '', strtolower( str_replace( ' ', '-', (string) $s['title'] ) ) );
		$id = substr( (string) $id, 0, 30 );
		if ( '' === $id || isset( $used[ $id ] ) ) {
			$id = 'section-' . ( (int) $i + 1 );
		}
		$used[ $id ] = true;
		$sections[]  = array(
			'id'      => $id,
			'type'    => $s['type'],
			'title'   => (string) $s['title'],
			'titleHi' => (string) $s['titleHi'],
			'feedUrl' => (string) $s['feedUrl'],
		);
	}
	if ( ! empty( $sections ) ) {
		$out['sections'] = $sections;
	}

	$response = new WP_REST_Response( $out );
	$response->header( 'Cache-Control', 'public, max-age=60' );
	return $response;
}
