import 'dart:async';
import 'dart:convert';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:http/http.dart' as http;

import '../../config/endpoints.dart';
import '../cache/cache_store.dart';
import '../security/safe_url.dart';

class FeedItem {
  final String id;
  final String title;
  final String link;
  final DateTime? date;

  /// When the post was last edited (WordPress `modified`). A post that was
  /// moved to another category or fixed later has a newer value than [date].
  final DateTime? modified;
  const FeedItem({
    required this.id,
    required this.title,
    required this.link,
    this.date,
    this.modified,
  });

  static const List<String> _months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];

  /// Edited clearly after it was published (more than 3 hours later).
  bool get isUpdated {
    final d = date, m = modified;
    return d != null && m != null && m.difference(d) > const Duration(hours: 3);
  }

  /// Shows the last-edited day (falls back to the publish day).
  String get dateLabel {
    final d = modified ?? date;
    if (d == null) return '';
    final day = d.day.toString().padLeft(2, '0');
    return '$day ${_months[d.month - 1]} ${d.year}';
  }
}

class FeedResult {
  final List<FeedItem> items;

  /// true when the network failed and an older saved copy is shown.
  final bool fromSavedCopy;
  const FeedResult(this.items, {this.fromSavedCopy = false});
}

class FeedFailure implements Exception {
  final bool offline;
  const FeedFailure({required this.offline});
}

/// Removes HTML tags and decodes the entities WordPress puts in titles.
String decodeHtml(String input) {
  var s = input.replaceAll(RegExp(r'<[^>]*>'), '');
  String fromCode(int code) =>
      (code > 0 && code <= 0x10FFFF) ? String.fromCharCode(code) : '';
  s = s.replaceAllMapped(
    RegExp(r'&#(\d{1,7});'),
    (m) => fromCode(int.parse(m[1]!)),
  );
  s = s.replaceAllMapped(
    RegExp(r'&#[xX]([0-9a-fA-F]{1,6});'),
    (m) => fromCode(int.parse(m[1]!, radix: 16)),
  );
  const named = {
    '&nbsp;': ' ',
    '&lt;': '<',
    '&gt;': '>',
    '&quot;': '"',
    '&apos;': "'",
    '&hellip;': '…',
    '&ndash;': '–',
    '&mdash;': '—',
    '&lsquo;': '‘',
    '&rsquo;': '’',
    '&ldquo;': '“',
    '&rdquo;': '”',
  };
  named.forEach((k, v) => s = s.replaceAll(k, v));
  return s.replaceAll('&amp;', '&').trim();
}

/// Reads a standard WordPress `wp/v2/posts` response. Bad rows are skipped.
List<FeedItem> parseFeed(String body) {
  final json = jsonDecode(body);
  if (json is! List) throw const FormatException('Feed is not a list');
  final items = <FeedItem>[];
  for (final row in json) {
    if (row is! Map<String, dynamic>) continue;
    final titleRaw = row['title'];
    final title = decodeHtml(
      titleRaw is Map ? '${titleRaw['rendered'] ?? ''}' : '${titleRaw ?? ''}',
    );
    final link = row['link'];
    if (title.isEmpty || link is! String || !SafeUrl.isAllowed(link)) continue;
    final dateRaw = row['date'];
    final modifiedRaw = row['modified'];
    items.add(FeedItem(
      id: '${row['id'] ?? link}',
      title: title,
      link: link,
      date: dateRaw is String ? DateTime.tryParse(dateRaw) : null,
      modified: modifiedRaw is String ? DateTime.tryParse(modifiedRaw) : null,
    ));
  }
  return items;
}

/// Downloads feeds with a safety net:
///  * fresh saved copy (< 2 min) is used without any network call
///  * if the network fails, a saved copy up to 24 h old is shown and marked
///  * anything older is never shown, so users do not see outdated news
/// WordPress date for the "before" filter: one day after [now], cut to the
/// minute (or to the second when [exact]).
String forceBeforeStamp(DateTime now, {bool exact = true}) {
  final t = now.add(const Duration(days: 1));
  String two(int n) => n.toString().padLeft(2, '0');
  final sec = exact ? two(t.second) : '00';
  return '${t.year.toString().padLeft(4, '0')}-${two(t.month)}-${two(t.day)}'
      'T${two(t.hour)}:${two(t.minute)}:$sec';
}

class FeedRepository {
  FeedRepository(
    this._cache, {
    http.Client? client,
    Future<bool> Function()? isOnline,
  })  : _client = client ?? http.Client(),
        _isOnline = isOnline ?? _defaultIsOnline;

  static const Duration freshFor = Duration(minutes: 2);
  static const Duration staleLimit = Duration(hours: 24);

  final CacheStore _cache;
  final http.Client _client;
  final Future<bool> Function() _isOnline;

  static Future<bool> _defaultIsOnline() async {
    try {
      final r = await Connectivity().checkConnectivity();
      return r.isNotEmpty && !r.every((e) => e == ConnectivityResult.none);
    } catch (_) {
      return true;
    }
  }

  static String normalizeUrl(String url) {
    final uri = Uri.parse(url);
    final q = Map<String, String>.of(uri.queryParameters);
    q.putIfAbsent('_fields', () => 'id,title,link,date,modified');
    // Newest *change* first, so a post that was edited or moved into a category
    // (for example to "Admit Card") shows up, not only brand-new posts.
    // An address that already says orderby=... keeps its own choice.
    q.putIfAbsent('orderby', () => 'modified');
    q.putIfAbsent('order', () => 'desc');
    final perPage = int.tryParse(q['per_page'] ?? '') ?? 6;
    q['per_page'] = perPage.clamp(1, 100).toString();
    return uri.replace(queryParameters: q).toString();
  }

  /// The address really sent to the website. For WordPress post lists a
  /// harmless "before" date (tomorrow) is added: it changes every minute, so a
  /// stuck query cache on the website's server can not keep an old list for
  /// long. A manual refresh also adds a unique tag and uses the exact second.
  static String _requestUrl(String url, {required bool force}) {
    final base = normalizeUrl(url);
    final u = Uri.parse(base);
    if (!u.path.contains('/wp-json/wp/v2/posts')) return base;
    final now = DateTime.now();
    return u.replace(queryParameters: {
      ...u.queryParameters,
      if (force) '_cb': now.millisecondsSinceEpoch.toString(),
      if (!u.queryParameters.containsKey('before')) 'before': forceBeforeStamp(now, exact: force),
    }).toString();
  }

  /// A saved copy (up to 24 h old) available instantly, or null. Lets screens
  /// draw at once and refresh quietly in the background.
  FeedResult? peek(String url) {
    if (!SafeUrl.isAllowed(url)) return null;
    final saved = _cache.get('feed:${normalizeUrl(url)}', maxAge: staleLimit);
    if (saved == null) return null;
    try {
      return FeedResult(parseFeed(saved));
    } catch (_) {
      return null;
    }
  }

  /// True when a saved copy is new enough to need no network call.
  bool isFresh(String url) =>
      SafeUrl.isAllowed(url) &&
      _cache.get('feed:${normalizeUrl(url)}', maxAge: freshFor) != null;

  /// A saved copy of [getText] with no network (or null).
  String? peekText(String url, {Duration maxAge = const Duration(days: 7)}) {
    if (!SafeUrl.isAllowed(url)) return null;
    return _cache.get('txt:$url', maxAge: maxAge);
  }

  /// Small cached download (for example a category list). Returns the saved
  /// copy if the network fails, or null.
  Future<String?> getText(String url, {Duration maxAge = const Duration(days: 7)}) async {
    if (!SafeUrl.isAllowed(url)) return null;
    final key = 'txt:$url';
    final fresh = _cache.get(key, maxAge: maxAge);
    if (fresh != null) return fresh;
    try {
      final r = await _client.get(Uri.parse(url)).timeout(Endpoints.requestTimeout);
      if (r.statusCode == 200) {
        final body = utf8.decode(r.bodyBytes, allowMalformed: true);
        await _cache.put(key, body);
        return body;
      }
    } catch (_) {/* use the saved copy */}
    return _cache.read(key)?.payload;
  }

  /// One download that is not saved (used for search results, so searching
  /// does not push the Home lists out of the saved copies).
  Future<List<FeedItem>> fetchOnce(String url) async {
    if (!SafeUrl.isAllowed(url)) throw const FeedFailure(offline: false);
    try {
      final response = await _client
          .get(Uri.parse(normalizeUrl(url)))
          .timeout(Endpoints.requestTimeout);
      if (response.statusCode != 200) throw const FormatException('Bad status');
      return parseFeed(utf8.decode(response.bodyBytes, allowMalformed: true));
    } catch (_) {
      throw FeedFailure(offline: !await _isOnline());
    }
  }

  Future<FeedResult> load(String url, {bool force = false}) async {
    if (!SafeUrl.isAllowed(url)) {
      throw const FeedFailure(offline: false);
    }
    final key = 'feed:${normalizeUrl(url)}';

    if (!force) {
      final fresh = _cache.get(key, maxAge: freshFor);
      if (fresh != null) {
        try {
          return FeedResult(parseFeed(fresh));
        } catch (_) {/* fall through to network */}
      }
    }

    try {
      final requestUrl = _requestUrl(url, force: force);
      final response = await _client
          .get(Uri.parse(requestUrl))
          .timeout(Endpoints.requestTimeout);
      if (response.statusCode != 200) {
        throw const FormatException('Bad status');
      }
      final body = utf8.decode(response.bodyBytes, allowMalformed: true);
      final items = parseFeed(body);
      await _cache.put(key, body);
      return FeedResult(items);
    } catch (_) {
      final stale = _cache.get(key, maxAge: staleLimit);
      if (stale != null) {
        try {
          return FeedResult(parseFeed(stale), fromSavedCopy: true);
        } catch (_) {/* fall through */}
      }
      throw FeedFailure(offline: !await _isOnline());
    }
  }
}
