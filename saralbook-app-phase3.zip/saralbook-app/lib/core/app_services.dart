import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'cache/cache_store.dart';
import 'config/config_controller.dart';
import 'feed/feed_repository.dart';
import 'home/home_layout.dart';
import 'home/recents_controller.dart';
import 'settings/settings_controller.dart';

/// Everything the screens share, created once at app start.
class AppServices {
  AppServices({
    required this.settings,
    required this.cache,
    required this.config,
    required this.feeds,
    required this.layout,
    required this.recents,
  });

  final SettingsController settings;
  final CacheStore cache;
  final ConfigController config;
  final FeedRepository feeds;
  final HomeLayoutController layout;
  final RecentsController recents;

  static Future<AppServices> create() async {
    final prefs = await SharedPreferences.getInstance();
    final settings = await SettingsController.load();
    final cache = CacheStore(prefs);
    final config = ConfigController(cache)..loadCached();
    return AppServices(
      settings: settings,
      cache: cache,
      config: config,
      feeds: FeedRepository(cache),
      layout: HomeLayoutController.load(prefs),
      recents: RecentsController.load(prefs),
    );
  }

  /// "Clear cache" in More: removes saved downloads, keeps user data.
  Future<void> clearCache() async {
    await cache.clear();
    config.useDefaults();
    unawaited(config.refresh(force: true));
  }
}

class AppScope extends InheritedWidget {
  const AppScope({super.key, required this.services, required super.child});

  final AppServices services;

  static AppServices of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope missing above this widget');
    return scope!.services;
  }

  @override
  bool updateShouldNotify(AppScope oldWidget) => false;
}
