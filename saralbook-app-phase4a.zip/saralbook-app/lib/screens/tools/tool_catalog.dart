import 'package:flutter/material.dart';

import '../../core/l10n/ltext.dart';
import '../../core/tools/calc_model.dart';
import '../../core/tools/calculators.dart';
import 'calc_tool_screen.dart';
import 'pomodoro_screen.dart';
import 'stopwatch_screen.dart';

/// One tile in the Tools tab.
class ToolEntry {
  final String id;
  final LText title;
  final LText description;
  final IconData icon;
  final ToolCategory category;
  final List<String> keywords;
  final WidgetBuilder builder;

  const ToolEntry({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    required this.category,
    required this.builder,
    this.keywords = const [],
  });

  /// Matches the search text against titles (both languages) and keywords.
  bool matches(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return true;
    return title.of('en').toLowerCase().contains(q) ||
        title.of('hi').toLowerCase().contains(q) ||
        description.of('en').toLowerCase().contains(q) ||
        keywords.any((k) => k.toLowerCase().contains(q));
  }
}

/// Every offline tool in the app. To add a tool: add it here (or to
/// calculators.dart for a calculator).
final List<ToolEntry> toolCatalog = [
  for (final c in allCalcTools)
    ToolEntry(
      id: c.id,
      title: c.title,
      description: c.description,
      icon: c.icon,
      category: c.category,
      keywords: c.keywords,
      builder: (context) => CalcToolScreen(tool: c),
    ),
  ToolEntry(
    id: 'stopwatch',
    title: t('Stopwatch', 'स्टॉपवॉच'),
    description: t('Time yourself with laps', 'लैप के साथ समय नापें'),
    icon: Icons.timer_outlined,
    category: ToolCategory.student,
    keywords: const ['timer', 'lap'],
    builder: (context) => const StopwatchScreen(),
  ),
  ToolEntry(
    id: 'pomodoro',
    title: t('Pomodoro Timer', 'पोमोडोरो टाइमर'),
    description: t('25-minute focus sessions with breaks', 'ब्रेक के साथ 25 मिनट के फ़ोकस सेशन'),
    icon: Icons.local_cafe_outlined,
    category: ToolCategory.student,
    keywords: const ['focus', 'study', 'break'],
    builder: (context) => const PomodoroScreen(),
  ),
];
