import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'auth/auth_controller.dart';
import 'auth/cloud_sync.dart';
import 'cache/cache_store.dart';
import 'config/admin_controller.dart';
import 'config/config_controller.dart';
import 'config/control_backend.dart';
import 'expense/currency.dart';
import 'feed/feed_repository.dart';
import 'groups/group_backend.dart';
import 'groups/group_controllers.dart';
import 'home/home_layout.dart';
import 'links/deep_link.dart';
import 'home/recents_controller.dart';
import 'personal/cloud_collection.dart';
import 'personal/personal_data.dart';
import 'settings/settings_controller.dart';

/// Everything the screens share, created once at app start.
class AppServices {
  AppServices({
    required this.settings,
    required this.cache,
    required this.config,
    required this.feeds,
    required this.layout,
    required this.recents,
    required this.auth,
    required this.personal,
    required this.sync,
    required this.rates,
    required this.groups,
    DeepLinkController? links,
    AdminController? admin,
  })  : links = links ?? DeepLinkController(),
        admin = admin ??
            AdminController(auth: auth, backend: const NoControlBackend(), config: config);

  final SettingsController settings;
  final CacheStore cache;
  final ConfigController config;
  final FeedRepository feeds;
  final HomeLayoutController layout;
  final RecentsController recents;
  final AuthController auth;
  final PersonalDataHub personal;
  final CloudProfileSync sync;
  final RateService rates;

  /// Group expenses of the signed-in account (null inside when signed out).
  final GroupsHub groups;

  /// A link that is waiting for its screen (e.g. a group invite).
  final DeepLinkController links;

  /// Is the signed-in person an owner/admin? (decided by the cloud, not the app)
  final AdminController admin;

  static Future<AppServices> create() async {
    final prefs = await SharedPreferences.getInstance();
    final settings = await SettingsController.load();
    final cache = CacheStore(prefs);
    final auth = AuthController.firebase();
    final control = FirestoreControlBackend(auth);
    final config = ConfigController(cache, control: control)..loadCached();
    final layout = HomeLayoutController.load(prefs);
    final rates = RateService(cache: cache, prefs: prefs)..loadCached();
    // Keeps theme/language/Home layout in the cloud for signed-in people.
    final sync = CloudProfileSync(auth: auth, settings: settings, layout: layout)..start();
    return AppServices(
      settings: settings,
      cache: cache,
      config: config,
      feeds: FeedRepository(cache),
      layout: layout,
      recents: RecentsController.load(prefs),
      auth: auth,
      sync: sync,
      rates: rates,
      admin: AdminController(auth: auth, backend: control, config: config),
      groups: GroupsHub(auth, FirestoreGroupBackend.new),
      personal: PersonalDataHub(
        auth,
        (uid, name) => FirestoreCollection(
          uid,
          name,
          orderBy: name == 'study_sessions' ? 'startedAt' : (name == 'expenses' ? 'date' : null),
          limit: name == 'study_sessions' ? 2000 : (name == 'expenses' ? 5000 : null),
        ),
      ),
    );
  }

  /// "Clear cache" in More: removes saved downloads, keeps user data.
  Future<void> clearCache() async {
    await cache.clear();
    config.useDefaults();
    unawaited(config.refresh(force: true));
  }
}

class AppScope extends InheritedWidget {
  const AppScope({super.key, required this.services, required super.child});

  final AppServices services;

  static AppServices of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope missing above this widget');
    return scope!.services;
  }

  @override
  bool updateShouldNotify(AppScope oldWidget) => false;
}
